### Further reading and information about python file
- heapq module:https://docs.python.org/3/library/heapq.html
- os mudule:https://docs.python.org/3/library/heapq.html
- zipfile module:https://docs.python.org/3/library/zipfile.html
- glob module:https://docs.python.org/3/library/glob.html